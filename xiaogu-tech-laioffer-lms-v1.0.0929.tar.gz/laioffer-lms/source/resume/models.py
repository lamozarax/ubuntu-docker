from django.conf import settings
from django.db import models
from django.utils import timezone


class Resume(models.Model):
    user = models.ForeignKey(
        'user.User', on_delete=models.CASCADE,
        related_name='resumes',
    )
    desc = models.CharField(max_length=100, )
    if settings.DEBUG:
        file = models.FileField(
            upload_to='static/uploads/%Y/%m/%d/',
        )
    else:
        file = models.FileField(
            upload_to='uploads/%Y/%m/%d/',
        )
    created_date = models.DateTimeField(auto_now=True)

    def __str__(self):
        return '{} - {}'.format(self.desc, self.created_date)


class ResumeComment(models.Model):
    resume = models.ForeignKey(
        Resume, on_delete=models.CASCADE,
        related_name='comments',
    )
    commenter = models.ForeignKey(
        'user.User', on_delete=models.CASCADE,
        related_name='commenter',
    )
    text = models.TextField()
    created_date = models.DateTimeField(default=timezone.now)
    if settings.DEBUG:
        attachment = models.FileField(
            upload_to='static/uploads/%Y/%m/%d/', blank=True, null=True,
        )
    else:
        attachment = models.FileField(
            upload_to='uploads/%Y/%m/%d/',
            blank=True, null=True,
        )

    def __str__(self):
        return '{}: {}'.format(self.commenter.username, self.text)
