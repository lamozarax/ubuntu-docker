from django.conf.urls import url
from . import views


urlpatterns = [
    url(
        regex=r"^(?P<course_id>\d+)/student/(?P<student_id>\d+)/$",
        view=views.ResumeCommentsView.as_view(),
        name='comments'
    ),
    url(
        regex=r"^student/(?P<student_id>\d+)/$",
        view=views.ResumeCommentsView.as_view(),
        name='comments_assistant'
    ),
    url(
        regex=r"^student/$",
        view=views.ResumeStudentTopView.as_view(),
        name='student_resume'
    ),
    url(
        regex=r"^course/(?P<pk>\d+)/$",
        view=views.ResumeClassView.as_view(),
        name='class_view'
    ),
]
