from rest_framework import viewsets

from .models import InterviewContent
from .serializers import InterviewContentsSerializer
from common.permissions import IsAuthen


class InterviewViewSet(viewsets.ModelViewSet):

    queryset = InterviewContent.objects.all()
    serializer_class = InterviewContentsSerializer
    permission_classes = (IsAuthen,)

    def update(self, request, *args, **kwargs):
        print('update', request.body, args, kwargs)
        return super(InterviewViewSet, self).update(
            request, *args, **kwargs)

    def destroy(self, request, pk=None):
        print('destroy')
        return super(InterviewViewSet, self).destroy(request, pk)
