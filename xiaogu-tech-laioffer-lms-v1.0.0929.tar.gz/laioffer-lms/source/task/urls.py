from django.conf.urls import url, include
from rest_framework.routers import DefaultRouter

from . import apis
from . import views

router = DefaultRouter()
router.register(r'tasks', apis.TaskViewSet)

urlpatterns = [
    url(
        regex=r'^api/',
        view=include(router.urls),
    ),
    url(
        regex=r"list/view-as-assignee/$",
        view=views.TaskListView.as_view(),
        name='view_list_as_assignee'
    ),
    url(
        regex=r"list/view-as-assignor/$",
        view=views.TaskListView.as_view(),
        name='view_list_as_assignor'
    ),
]
