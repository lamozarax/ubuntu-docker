#!/usr/bin/python
# -*- coding: utf-8 -*-
from django.core.urlresolvers import reverse_lazy

from .contants import (
    GROUP_SUPERVISOR, GROUP_TEACHER, GROUP_ASSISTANT,
    GROUP_STUDENT,
)


def get_default_url_of_role(user):
    url = '404.html'
    if user.is_in_group(GROUP_SUPERVISOR):
        url = reverse_lazy('user:list')
    elif user.is_in_group(GROUP_TEACHER):
        url = reverse_lazy('user:teacher')
    elif user.is_in_group(GROUP_STUDENT):
        url = reverse_lazy('user:student_landing')
    elif user.is_in_group(GROUP_ASSISTANT):
        url = reverse_lazy('task:view_list_as_assignee')
    else:
        print('[ERROR]undefined user role, pls check')

    return url
