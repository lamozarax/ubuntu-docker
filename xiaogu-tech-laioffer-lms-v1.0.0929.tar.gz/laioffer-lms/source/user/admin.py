from django.contrib import admin
from django.contrib.auth.admin import UserAdmin

from resume.models import Resume
from .models import (
    User, WorkExperience, StudyExperience
)


class WorkExpInline(admin.StackedInline):
    model = WorkExperience
    fk_name = 'user'


class StudyExpInline(admin.StackedInline):
    model = StudyExperience
    fk_name = 'user'


class ResumeInline(admin.StackedInline):
    model = Resume
    fk_name = 'user'


class CustomUserAdmin(UserAdmin):
    inlines = (StudyExpInline, WorkExpInline, ResumeInline, )
    list_display = ('username', 'email', 'first_name', 'last_name', )

    def role(self, instance):
        return instance.role

    def get_inline_instances(self, request, obj=None):
        if not obj:
            return list()
        return super(CustomUserAdmin, self).get_inline_instances(request, obj)


admin.site.register(User, CustomUserAdmin)
