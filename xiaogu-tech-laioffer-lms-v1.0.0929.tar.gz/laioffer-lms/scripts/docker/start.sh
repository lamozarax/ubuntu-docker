#!/bin/bash
# This is the entry point to start up the LMS.

set -ex

bash /sites/$SITENAME/scripts/docker/cleanup.sh

/etc/init.d/nginx start -D

cd /sites/$SITENAME/source/
gunicorn --bind unix:/tmp/$SITENAME.socket config.wsgi:application --access-logfile /tmp/gunicorn.access.log --error-logfile /tmp/gunicorn.error.log
