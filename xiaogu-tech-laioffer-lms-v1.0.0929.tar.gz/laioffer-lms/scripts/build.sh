#!/bin/bash

PROJECT_CURRENT_SOURCE_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
PROJECT_SOURCE_DIR=${PROJECT_CURRENT_SOURCE_DIR}/..
DOCKER_SOURCE_DIR=${PROJECT_SOURCE_DIR}/scripts/docker
BUILD_DIR=${PROJECT_SOURCE_DIR}/target

mkdir -p ${BUILD_DIR} && cd ${BUILD_DIR} && echo "Entering build dir ${BUILD_DIR}"
rm -rf site git
git clone file://${PROJECT_SOURCE_DIR} --depth 1 --separate-git-dir git --single-branch site

cp -f ${DOCKER_SOURCE_DIR}/Dockerfile ${DOCKER_SOURCE_DIR}/.dockerignore ${BUILD_DIR}
docker build -t laioffer-lms:latest -f Dockerfile $@ ${BUILD_DIR}
