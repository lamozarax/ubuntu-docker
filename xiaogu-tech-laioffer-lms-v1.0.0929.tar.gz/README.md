# Learning Management System (LMS)

## Deployment

To deploy, we run the nginx server in a docker container, which connects a
remote PostgreSQL running on Amazon RDS web services.

1. **Database**. First things first, we should create a database. Please follow the Amazon RDS
documents. To create associated users and roles, refer to `scripts/createdb.sh`.
1. **Build**. For every deployment (e.g. every commit), we have to rebuild the
docker container (either us or Jenkins). Please run the following command,
after which you should see a `laioffer-lms:latest` image in you machine.
    ```bash
    $ bash -ex scripts/build.sh
    ```
1. **Configure**. Next we create a `env.sh` configuration file according to the database
settings which is passed to docker container as environment variables.
    ```bash
    LMS_DB_HOST=<the host of the DB>
    LMS_DB_PORT=<the port of the DB>
    LMS_DB_NAME=<the name of the data>
    LMS_DB_USER=<the user that access the DB>
    LMS_DB_PWD=<the password of the user accessing the DB>
    ```
1. **Initialize**. For the very first time for database, we should initialize it.
    ```bash
    $ docker run --env-file=env.sh \
                 --entrypoint=/sites/learn/scripts/docker/cleanup.sh \
                 laioffer-lms:latest
    ```
1. **Deploy**. [Jenkins](https://jenkins-internal.laioffer.com/job/lms-deploy/)
will upload newly built images to ECS Repository, and we'll deploy there.
Please following instructions accordingly. If building the Docker image locally,
you can run the `scripts/run.sh` script on your local host.
To check, open your favorite web browser and hit: `http://127.0.0.1`

## Development

This web system makes uses of Python, Django, Docker, Nginx and PostgreSQL.
Please install them on your dev machine.

### Setting up local database

For a local runtime deployment, you can set up a PostgreSQL on you localhost
and make docker containers access that instead of remote Amazon RDS. Do NOT
connect to production database on your dev containers.

1. After installing PostgreSQL, you have to add the following lines to your
`postgresql.conf` file (on macOS, see `/usr/local/var/postgres/postgresql.conf`)
so that your localhost database listens on addresses that containers can access.
    ```
    listen_addresses = '*'
    ```
1. Meanwhile, you also need to specify the client access authentication rules
to make you LMS container be able to connect to the host PostgreSQL database.
Add the following lines to `pg_hba.conf`:
    ```
    host    all            all             0.0.0.0/0                md5
    ```
1. After starting PostgreSQL (on macOS, use `brew services start postgresql`),
you can set up `env.sh` file (see above) and then create the database using:
    ```bash
    $ bash -ex scripts/createdb.sh
    ```

