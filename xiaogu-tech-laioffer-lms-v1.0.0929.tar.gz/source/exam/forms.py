from django import forms
from django.forms.models import inlineformset_factory

from datetimewidget.widgets import DateTimeWidget
from .models import Exam, Problem


class ExamForm(forms.ModelForm):

    def __init__(self, *args, **kwargs):
        super(ExamForm, self).__init__(*args, **kwargs)

        if ('instance' not in kwargs):
            del self.fields['started']

    class Meta:
        fields = ('started', 'course', 'title', 'start', 'end')
        model = Exam
        dateTimeOptions = {
            'format': 'yyyy-mm-dd hh:ii:ss',
            'autoclose': True,
        }
        widgets = {
            # Use localization and bootstrap 3
            'start': DateTimeWidget(
                # attrs={'id': "yourdatetimeid"},
                options=dateTimeOptions,
                bootstrap_version=3
            ),
            'end': DateTimeWidget(
                # attrs={'id': "yourdatetimeid"},
                options=dateTimeOptions,
                bootstrap_version=3
            )
        }


ProblemFormset = inlineformset_factory(
    Exam, Problem, extra=1,
    fields=('content', 'minutes', 'full_marks'), can_delete=True)
