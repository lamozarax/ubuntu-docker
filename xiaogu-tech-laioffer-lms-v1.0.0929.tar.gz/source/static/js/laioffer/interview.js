var tas = $('textarea.cm')
var data_to_send = [];
var last_saved_values = [];
var cms = [];
var pre_values = {};

$(document).ready(function() {
    $('pre.prettyprint').each(function() {
        var key = $(this).data('content-id');
        pre_values[key] = $(this).text();
    });

    convertTextarea();
    prettyPrint();

    var CHECK_INTERVAL = 500;
    setInterval(checkChanged, CHECK_INTERVAL);
    var SEND_INTERVAL = 3000;
    setInterval(sendInput, SEND_INTERVAL);
    var UPDATE_INTERVAL = 3000;
    setInterval(updateContents, UPDATE_INTERVAL);
})

function updateContents() {
    $('pre.prettyprint').each(function() {
        var content_id = $(this).data('content-id');
        var field = $(this).data('field-name');

        var url = "/interview/api/interviews/" + content_id + "/";
        var data = {};
        $.ajax({
          url: url,
          method: 'GET',
          data: null,
          context: {
            pre: $(this),
            field: field,
          },
          success: function( result ) {
            // console.log(result);
            var key = $(this.pre).data('content-id');
            if (pre_values[key] != result[this.field])
            {
                console.log('not equal: ' + pre_values[key]);
                pre_values[key] = result[this.field];
                this.pre.removeClass('prettyprinted');
                this.pre.text(result[this.field]);
                prettyPrint();
            }
          }
        });
    });
}

function convertTextarea() {
    var i = 0;
    tas.each(function () {

        $(this).id = 'ta-' + i;
        last_saved_values.push(this.value);

        var cm = CodeMirror.fromTextArea(this, {
            mode: {name: "python",
                   version: 3,
                   singleLineStringErrors: false},
            lineNumbers: true,
            indentUnit: 4,
            matchBrackets: true,
        });

        cms.push(cm);
        ++i;
    });
}

function checkChanged() {
    for (var i=0, l=cms.length; i<l; i++) {
        var form = cms[i].getWrapperElement().parentNode;

        if(last_saved_values[i] !== cms[i].getValue()) {
            $(form).find('label.hint').text('changed');
        }
    }
}

function sendInput() {
    for (var i=0, l=cms.length; i<l; i++) {

        var form = cms[i].getWrapperElement().parentNode;

        if(last_saved_values[i] !== cms[i].getValue()) {
            var lbl = $(form).find('label.hint');
            var content_id = $(form).data('content-id');
            var content = cms[i].getValue();
            var field = $(form).data('field-name');

            var url = "/interview/api/interviews/" + content_id + "/";
            var data = {};
            data[field] = content;
            data['id'] = content_id;
            $.ajax({
              url: url,
              method: 'PATCH',
              data: data,
              context: {
                lbl: lbl,
                content: content,
                i: i,
              },
              success: function( result ) {
                // console.log(result);
                last_saved_values[this.i] = this.content;
                this.lbl.text('saved');
              }
            });
        }
    }
}
