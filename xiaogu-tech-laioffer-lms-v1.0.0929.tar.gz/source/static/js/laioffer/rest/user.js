function update_user(user_id, method, data, context, success_fn = null, error_fn = null) {
    var url = "/user/api/users/" + user_id + "/";
    $.ajax({
        url: url,
        method: method,
        data: data,
        context: context,
        success: function(res, textStatus, jqXHR) {
            console.log(url + ', textStatus: ' + textStatus + ', res: ' + res);
            if (success_fn !== null) {
                success_fn(res, this);
            }
        },
        error: function(jqXHR, textStatus, errorThrown) {
            console.log(this.url + ', textStatus: ' + textStatus);
            console.log(errorThrown);
            if (error_fn !== null) {
                error_fn();
            }
        }
    });
}
