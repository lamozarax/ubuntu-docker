from django.conf.urls import url
from . import views


urlpatterns = [
    url(
        regex=r'^form/$',
        view=views.FormTutorialView.as_view(),
        name='form',
    ),
]
