from django.contrib import admin

from .forms import AuthorForm
from .models import Author, Book


class AuthorAdmin(admin.ModelAdmin):

    form = AuthorForm

    fieldsets = (
        (None, {'fields': ('name', 'books')}),
    )


admin.site.register(Author, AuthorAdmin)
admin.site.register(Book)
