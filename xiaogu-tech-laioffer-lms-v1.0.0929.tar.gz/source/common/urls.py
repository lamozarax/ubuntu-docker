from django.conf.urls import url

from markdownx.views import MarkdownifyView
from . import views


urlpatterns = [
    url(
        regex=r'^upload/$',
        view=views.MyImageUploadView.as_view(),
        name='markdownx_upload',
    ),
    url(
        regex=r'^markdownify/$',
        view=MarkdownifyView.as_view(),
        name='markdownx_markdownify',
    ),
    url(
        regex=r'^$',
        view=views.TestMarkdownxCreateView.as_view(),
    ),
]
