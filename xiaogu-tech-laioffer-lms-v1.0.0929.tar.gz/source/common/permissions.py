from rest_framework.permissions import IsAuthenticated


class IsAuthen(IsAuthenticated):
    pass
