from django.conf.urls import url, include
from rest_framework.routers import DefaultRouter

from . import views
from . import views_auth
from . import apis


router = DefaultRouter()
router.register(r'users', apis.UserViewSet)

urlpatterns = [
    url(
        regex=r'^api/',
        view=include(router.urls),
    ),
    url(
        regex=r"create/$",
        view=views.CreateOrUpdateUserView.as_view(),
        name='create'
    ),
    url(
        regex=r"list/$",
        view=views.UserListView.as_view(),
        name='list'
    ),
    url(
        regex=r"edit/(?P<pk>\d+)$",
        view=views.CreateOrUpdateUserView.as_view(),
        name='edit'
    ),
    url(
        regex=r"login/",
        view=views_auth.MyLoginView.as_view(),
        name='login'
    ),
    url(
        regex=r"logout/",
        view=views_auth.MyLogoutView.as_view(),
        name='logout'
    ),
    url(
        regex=r"teacher/$",
        view=views.TeacherView.as_view(),
        name='teacher'
    ),
    url(
        regex=r"^student/landing$",
        view=views.StudentView.as_view(),
        name='student_landing'
    ),
    url(
        regex=r"^landing/$",
        view=views_auth.UserRedirectView.as_view(),
        name='landing'
    ),
    url(
        regex=r"profile/",
        view=views.ProfileView.as_view(),
        name='profile'
    ),
    url(
        regex=r"delete/(?P<pk>\d+)$",
        view=views.UserDeleteView.as_view(),
        name='delete'
    ),
]
