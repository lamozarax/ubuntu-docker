"""config URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/1.11/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  url(r'^$', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  url(r'^$', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.conf.urls import url, include
    2. Add a URL to urlpatterns:  url(r'^blog/', include('blog.urls'))
"""
from django.conf import settings
from django.conf.urls import url, include
from django.contrib import admin

from common.views import InitView, ErrorPageView

urlpatterns = [
    url(r'^admin/', admin.site.urls),
    url(r'^$', InitView.as_view()),
    url(r'^user/', include('user.urls', namespace='user')),
    url(r'^course/', include('course.urls', namespace='course')),
    url(r'^markdownx/', include('common.urls')),
    url(r'^playground/', include('playground.urls', namespace='playground')),
    url(r'^resume/', include('resume.urls', namespace='resume')),
    url(r'^interview/', include('interview.urls', namespace='interview')),
    url(r'^exam/', include('exam.urls', namespace='exam')),
    url(r'^task/', include('task.urls', namespace='task')),
    url(r'^404/$', ErrorPageView.page_not_found, ),
    url(r'^403/$', ErrorPageView.permission_denied, ),
]

handler403 = ErrorPageView.permission_denied
handler404 = ErrorPageView.page_not_found
handler500 = ErrorPageView.page_error

if settings.DEBUG:
    import debug_toolbar
    urlpatterns = [
        url(r'^__debug__/', include(debug_toolbar.urls)),
    ] + urlpatterns
