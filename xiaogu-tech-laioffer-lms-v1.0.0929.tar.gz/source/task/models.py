from django.core.urlresolvers import reverse_lazy
from django.db import models

from common.models import TimeStampedModel
from exam.models import ExamPaper
from interview.models import Interview
from resume.models import Resume
from user.models import User


class Task(TimeStampedModel):

    TODO = 'TODO'
    DOING = 'DOING'
    DONE = 'DONE'
    STATUS_CHOICES = (
        (TODO, 'TODO'),
        (DOING, 'DOING'),
        (DONE, 'DONE'),
    )

    INTERVIEW = 'interview'
    RESUME = 'resume'
    EXAM_PAPER = 'exam_paper'
    TTYPE_CHOICES = (
        (INTERVIEW, 'INTERVIEW'),
        (RESUME, 'RESUME'),
        (EXAM_PAPER, 'EXAM_PAPER'),
    )

    assignor = models.ForeignKey(User, related_name='assigned_tasks')
    assignee = models.ForeignKey(User, related_name='tasks')

    status = models.CharField(
        max_length=10,
        choices=STATUS_CHOICES,
        default=TODO,
    )
    ttype = models.CharField(
        max_length=10,
        choices=TTYPE_CHOICES,
    )

    resume = models.OneToOneField(Resume, null=True, blank=True,
                                  on_delete=models.CASCADE)
    interview = models.OneToOneField(Interview, null=True, blank=True,
                                     on_delete=models.CASCADE)
    exam_paper = models.OneToOneField(ExamPaper, null=True, blank=True,
                                      on_delete=models.CASCADE)

    def __str__(self):
        return '{} task assigned by {} to {}'.format(
            self.ttype,
            self.assignor,
            self.assignee,
        )

    @property
    def student(self):
        stu = None
        if self.ttype == Task.INTERVIEW:
            stu = self.interview.interviewee
        elif self.ttype == Task.RESUME:
            stu = self.resume.user
        elif self.ttype == Task.EXAM_PAPER:
            stu = self.exam_paper.student
        return stu

    @property
    def process_url(self):
        url = ''
        if self.ttype == Task.INTERVIEW:
            url = reverse_lazy('interview:update_contents_assistant', kwargs={
                'interview_id': self.interview.id,
            })
        elif self.ttype == Task.RESUME:
            url = reverse_lazy('resume:comments_assistant', kwargs={
                'student_id': self.resume.user_id,
            })
            url = url + '?resume_id=' + str(self.resume.id)
        elif self.ttype == Task.EXAM_PAPER:
            url = reverse_lazy('exam:score', kwargs={
                'exam_paper_id': self.exam_paper.id,
            })
        return url
