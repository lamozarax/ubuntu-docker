from rest_framework import viewsets

from .models import Task
from .serializers import TaskSerializer
from common.permissions import IsAuthen


class TaskViewSet(viewsets.ModelViewSet):

    queryset = Task.objects.all()
    serializer_class = TaskSerializer
    permission_classes = (IsAuthen,)

    def update(self, request, *args, **kwargs):
        print('update', request.body, args, kwargs)
        return super(TaskViewSet, self).update(
            request, *args, **kwargs)

    def destroy(self, request, pk=None):
        print('destroy')
        return super(TaskViewSet, self).destroy(request, pk)
