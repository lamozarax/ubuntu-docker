from django.core.urlresolvers import reverse_lazy
from django.http import JsonResponse
from django.shortcuts import get_object_or_404
from django.views.generic import View

from common.utils import (
    start_of_month_in_milli, end_of_month_in_milli,
    ts_in_milli_to_dt, utc_ts_in_milli_to_dt,
)
from common.utils import zone_conflict
from course.models import Course
from user.models import User


class GetStudentCourseModulesApi(View):

    def get(self, request, pk):
        if not request.user.is_authenticated():
            return
        user = get_object_or_404(User, id=pk)
        ts_from = int(request.GET.get('from', start_of_month_in_milli()))
        ts_to = int(request.GET.get('to', end_of_month_in_milli()))
        courses = user.enrolling.all()
        results = []
        index = 0
        types = ['event-important', 'event-success', 'event-warning',
                 'event-info', 'event-inverse', 'event-special']
        for course in courses:
            lectures = course.lectures.filter(start__range=(
                ts_in_milli_to_dt(ts_from),
                ts_in_milli_to_dt(ts_to),
            ))
            for lecture in lectures:
                obj = lecture.to_obj()
                obj['class'] = types[index % len(types)]
                obj['url'] = reverse_lazy(
                    'course:lecture', kwargs={'lecture_id': lecture.pk})
                results.append(obj)

            exams = course.exams.filter(start__range=(
                ts_in_milli_to_dt(ts_from),
                ts_in_milli_to_dt(ts_to),
            ))
            for exam in exams:
                obj = exam.to_obj()
                obj['class'] = types[index % len(types)]
                obj['url'] = reverse_lazy(
                    'exam:student', kwargs={'exam_id': exam.pk})
                results.append(obj)
            index = index + 1
        data = {
            'success': 1,
            'result': results,
        }
        return JsonResponse(data)


class GetCourseModulesApi(View):

    def get(self, request, pk):
        if not request.user.is_authenticated():
            return

        course = get_object_or_404(Course, id=pk)
        ts_from = int(request.GET.get('from', start_of_month_in_milli()))
        ts_to = int(request.GET.get('to', end_of_month_in_milli()))

        results = []
        lectures = course.lectures.filter(start__range=(
            ts_in_milli_to_dt(ts_from),
            ts_in_milli_to_dt(ts_to),
        ))
        for lecture in lectures:
            obj = lecture.to_obj()
            obj['class'] = 'event-important'
            obj['url'] = reverse_lazy(
                'course:edit_lecture',
                kwargs={'lecture_id': lecture.pk, 'course_id': pk})
            results.append(obj)

        exams = course.exams.filter(start__range=(
            ts_in_milli_to_dt(ts_from),
            ts_in_milli_to_dt(ts_to),
        ))
        for exam in exams:
            obj = exam.to_obj()
            obj['class'] = 'event-important'
            obj['url'] = reverse_lazy(
                'course:edit_exam',
                kwargs={'exam_id': exam.pk, 'course_id': pk})
            results.append(obj)

        data = {
            'success': 1,
            'result': results,
        }
        return JsonResponse(data)


class GetSupervisorCourseModulesViewApi(View):

    def get(self, request):
        if not request.user.is_authenticated():
            return

        ts_from = int(request.GET.get('from', start_of_month_in_milli()))
        ts_to = int(request.GET.get('to', end_of_month_in_milli()))
        courses = Course.objects.filter(visible=True)
        results = []
        index = 0
        types = ['event-important', 'event-success', 'event-warning',
                 'event-info', 'event-inverse', 'event-special']
        zones = courses.order_by('course_zone')
        zones = zones.values('course_zone').distinct()
        # print('zones', zones)
        zone_color_dic = {}
        for zone in zones:
            zone = zone['course_zone']
            zone_color_dic[zone] = types[index % len(types)]
            index = index + 1
        # print('zone_color_dic', zone_color_dic)
        for course in courses:
            lectures = course.lectures.filter(start__range=(
                ts_in_milli_to_dt(ts_from),
                ts_in_milli_to_dt(ts_to),
            ))
            for lecture in lectures:
                obj = lecture.to_obj()
                obj['url'] = reverse_lazy(
                    'course:lecture', kwargs={'lecture_id': lecture.pk})
                obj['class'] = zone_color_dic[course.course_zone]
                results.append(obj)
            exams = course.exams.filter(start__range=(
                ts_in_milli_to_dt(ts_from),
                ts_in_milli_to_dt(ts_to),
            ))
            for exam in exams:
                obj = exam.to_obj()
                obj['class'] = zone_color_dic[course.course_zone]
                obj['url'] = reverse_lazy(
                    'course:edit_exam',
                    kwargs={'exam_id': exam.pk, 'course_id': course.pk})
                results.append(obj)
        data = {
            'success': 1,
            'result': results,
        }
        return JsonResponse(data)


class GetConflictView(View):

    def get(self, request):
        if not request.user.is_authenticated():
            return

        ts_from = int(request.GET.get('from', start_of_month_in_milli()))
        ts_to = int(request.GET.get('to', end_of_month_in_milli()))
        courses = Course.objects.filter(visible=True)
        zone_conflict_items = []
        for course in courses:
            lectures = course.lectures.filter(start__range=(
                utc_ts_in_milli_to_dt(ts_from),
                utc_ts_in_milli_to_dt(ts_to),
            ))
            for lecture in lectures:
                obj = lecture.to_obj()
                zone_conflict_items.append(obj)
            exams = course.exams.filter(start__range=(
                utc_ts_in_milli_to_dt(ts_from),
                utc_ts_in_milli_to_dt(ts_to),
            ))
            for exam in exams:
                obj = exam.to_obj()
                zone_conflict_items.append(obj)
        # print('zone_conflict_items', zone_conflict_items)
        zone_conflict_list = zone_conflict(zone_conflict_items)
        data = {
            'success': 1,
            'result': zone_conflict_list,
        }
        return JsonResponse(data)
