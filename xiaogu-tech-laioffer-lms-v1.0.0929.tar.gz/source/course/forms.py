from django import forms
from datetimewidget.widgets import DateTimeWidget

from user.contants import GROUP_ASSISTANT
from user.models import User
from .models import Lecture


class LectureForm(forms.ModelForm):

    class Meta:
        fields = '__all__'
        model = Lecture
        dateTimeOptions = {
            'format': 'yyyy-mm-dd hh:ii:ss',
            'autoclose': True,
        }
        widgets = {
            # Use localization and bootstrap 3
            'start': DateTimeWidget(
                # attrs={'id': "yourdatetimeid"},
                options=dateTimeOptions,
                bootstrap_version=3
            ),
            'end': DateTimeWidget(
                # attrs={'id': "yourdatetimeid"},
                options=dateTimeOptions,
                bootstrap_version=3
            )
        }
