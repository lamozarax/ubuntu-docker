from django import forms

from .models import InterviewContent, Interview

from user.models import User
from django.utils.translation import gettext_lazy as _

class InterviewForm(forms.ModelForm):

    def __init__(self, *args, **kwargs):
        super(InterviewForm, self).__init__(*args, **kwargs)
        initial = kwargs.get("initial", None)
        if initial and initial['interviewer'] and initial['interviewee']:
            self.fields['interviewer'].queryset = User.objects.filter(
                id=initial['interviewer'].id
                )
            self.fields['interviewee'].queryset = User.objects.filter(
                id=initial['interviewee'].id
                )

    class Meta:
        model = Interview
        fields = ('title', 'interviewee', 'interviewer', )
        widgets = {
            'interviewee': forms.widgets.Select(
                attrs={'readonly': True}),
            'interviewer': forms.widgets.Select(
                attrs={'readonly': True}),
        }
        labels = {
            'interviewer': _('Class Manager'),
        }


class InterviewFinishForm(forms.ModelForm):

    class Meta:
        model = Interview
        fields = ('summary', )


class InterviewContentForm(forms.ModelForm):

    class Meta:
        model = InterviewContent
        fields = ('question',)
