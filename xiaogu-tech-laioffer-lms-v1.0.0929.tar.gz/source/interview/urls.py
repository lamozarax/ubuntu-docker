from django.conf.urls import url, include
from rest_framework.routers import DefaultRouter

from . import apis
from . import views

router = DefaultRouter()
router.register(r'interviews', apis.InterviewViewSet)

urlpatterns = [
    url(
        regex=r'^api/',
        view=include(router.urls),
    ),
    url(
        regex=r"^create/(?P<student_id>\d+)/(?P<course_id>\d+)/$",
        view=views.InterviewCreateView.as_view(),
        name='create'
    ),
    url(
        regex=r"^(?P<interview_id>\d+)/contents/(?P<course_id>\d+)/$",
        view=views.InterviewContentsUpdateView.as_view(),
        name='update_contents'
    ),
    url(
        regex=r"^(?P<interview_id>\d+)/contents/$",
        view=views.InterviewContentsUpdateView.as_view(),
        name='update_contents_assistant'
    ),
    url(
        regex=r"^student/$",
        view=views.InterviewStudentView.as_view(),
        name='student'
    ),
    url(
        regex=r"^course/(?P<pk>\d+)/$",
        view=views.InterviewClassView.as_view(),
        name='class_view'
    ),
]
