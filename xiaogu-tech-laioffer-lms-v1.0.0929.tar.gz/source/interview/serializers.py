from rest_framework import serializers

from .models import InterviewContent


class InterviewContentsSerializer(serializers.ModelSerializer):

    class Meta:
        model = InterviewContent
        fields = '__all__'
