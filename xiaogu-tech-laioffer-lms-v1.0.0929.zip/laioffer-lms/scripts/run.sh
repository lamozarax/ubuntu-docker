#!/bin/bash

# This script builds and runs the laioffer-lms docker container on your local host

LMS_ENV_FILE=../env.sh
LMS_HOST_PORT=80

# erase existing containers
docker kill $(docker ps -q) 2> /dev/null
docker rm -f $(docker ps -a -q) 2> /dev/null

set -ex

cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd

./build.sh

docker run --env-file=${LMS_ENV_FILE} -p ${LMS_HOST_PORT}:80 --name=laioffer-lms -d laioffer-lms:latest
