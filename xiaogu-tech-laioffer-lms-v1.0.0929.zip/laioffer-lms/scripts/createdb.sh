#!/bin/bash

CURRENT_SOURCE_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

source ${CURRENT_SOURCE_DIR}/../env.sh

#psql --command "DROP DATABASE lms;"
psql --command "CREATE DATABASE ${LMS_DB_NAME};"
psql --command "DROP USER IF EXISTS ${LMS_DB_USER};"
psql --command "CREATE USER ${LMS_DB_USER} WITH PASSWORD '${LMS_DB_PWD}';"
psql --command "ALTER ROLE ${LMS_DB_USER} SET client_encoding TO 'utf8';"
psql --command "ALTER ROLE ${LMS_DB_USER} SET default_transaction_isolation TO 'read committed';"
psql --command "ALTER ROLE ${LMS_DB_USER} SET timezone TO 'UTC';"
psql --command "GRANT ALL PRIVILEGES ON DATABASE ${LMS_DB_NAME} TO ${LMS_DB_USER};"

psql -d ${LMS_DB_NAME} -U ${LMS_DB_USER} --password -f ${CURRENT_SOURCE_DIR}/user_uploadcv.psql
