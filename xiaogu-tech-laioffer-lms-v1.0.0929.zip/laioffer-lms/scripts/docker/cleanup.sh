#!/bin/bash
# This migrates the Django model to update existing database.

mypath=$(cd "$(dirname "$0")"; pwd)
cd ${mypath}/../../source/
echo 'current path:'
echo '-------------'
pwd

# echo 'delete all migration files:'
# echo '---------------------------'
# find . -path *migrations* -name "*.py" -not -path "*__init__*"
# find . -path *migrations* -name "*.py" -not -path "*__init__*" -exec rm {} \;

echo 'delete .sqlite3'
echo '---------------'
rm -rf ../database/db.sqlite3

# echo 'use backup database: '
# echo '---------------------------'
cp ../database/backups/db.sqlite3 ../database/


echo 'makemigrations and migrate'
echo '--------------------------'
python manage.py makemigrations
python manage.py migrate

# echo 'initialize db'
# echo '-------------'
# python manage.py initdb
