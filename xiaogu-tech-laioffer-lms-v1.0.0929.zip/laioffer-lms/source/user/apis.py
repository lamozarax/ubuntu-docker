from rest_framework import viewsets

from .models import User
from .serializers import UserSerializer
from common.permissions import IsAuthen


class UserViewSet(viewsets.ModelViewSet):

    queryset = User.objects.all()
    serializer_class = UserSerializer
    permission_classes = (IsAuthen,)

    def update(self, request, *args, **kwargs):
        print('update', request.body, args, kwargs)
        return super(UserViewSet, self).update(
            request, *args, **kwargs)
