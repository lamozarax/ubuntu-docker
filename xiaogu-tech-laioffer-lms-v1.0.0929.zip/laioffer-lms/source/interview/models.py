from django.db import models
from django.utils import timezone

from user.models import User


class Interview(models.Model):
    interviewee = models.ForeignKey(
        User, on_delete=models.CASCADE,
        related_name='interviews_taken',
    )
    interviewer = models.ForeignKey(
        User, on_delete=models.CASCADE,
        related_name='interviews_started',
    )
    created_date = models.DateTimeField(default=timezone.now)
    title = models.CharField(max_length=100)
    summary = models.TextField(blank=True)


class InterviewContent(models.Model):
    interview = models.ForeignKey(
        Interview, on_delete=models.CASCADE,
        related_name='contents'
    )
    question = models.TextField(blank=True)
    answer = models.TextField(blank=True)
    comment = models.TextField(blank=True)
