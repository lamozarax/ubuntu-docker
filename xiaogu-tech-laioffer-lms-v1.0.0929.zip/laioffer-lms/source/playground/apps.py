from django.apps import AppConfig


class PlaygroundConfig(AppConfig):
    name = 'playground'
