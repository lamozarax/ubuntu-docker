from django.views.generic import TemplateView


class FormTutorialView(TemplateView):

    template_name = 'playground/form.html'
    current_name = ''

    def get(self, request):
        return self.render_to_response({
            'view': self,
        })

    def post(self, request):
        print(request.POST)

        return self.render_to_response({
            'view': self,
        })
