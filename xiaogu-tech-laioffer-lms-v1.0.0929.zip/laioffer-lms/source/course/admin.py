from django.contrib import admin

from exam.models import Exam
from .models import Course, Lecture


class LectureInline(admin.StackedInline):
    model = Lecture


class ExamInline(admin.StackedInline):
    model = Exam


@admin.register(Course)
class CourseAdmin(admin.ModelAdmin):
    list_display = ['full_name']
    inlines = [LectureInline, ExamInline]
