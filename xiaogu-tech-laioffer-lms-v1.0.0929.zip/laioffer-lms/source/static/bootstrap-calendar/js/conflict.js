var url = "/course/get_conflict";
$.ajax({
    url: url,
    method: 'GET',
    data: {
    //content: content,
    //answer_id: answer_id,
    },
    context:{
        url: url,
    },
    success: function( result ) {
        // var div = $('div.cal-day-inmonth').first();
        // var month = div.children().eq(0).attr('data-cal-date'); // "2017-06-01"

        for(var i=0; i<result.result.length; i++) {
            var day = result.result[i];
            var btn = $('<button type="button" class="btn btn-danger">' + day + '</button>');
            btn.attr('day', day);
            btn.on("click", function(){
                var day = $(this).attr('day');
                // console.log();
                $('div.cal-day-inmonth').eq(day - 1).find('span').trigger('click');
            });
            $("#conflict").append(btn);
        }


    }
});
