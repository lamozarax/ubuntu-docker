var calendar = null;
(function($) {

    "use strict";

    // console.log('/course/' + course_id + '/modules/');

    var options = {
        events_source: $.py.get_modules_url,
        // events_source: function () { return []; },
        // events_source: [{
        //     "id": 293,
        //     "title": "Event 1",
        //     "url": "http://example.com",
        //     "class": "event-important",
        //     "start": 12039485678000, // Milliseconds
        //     "end": 1497078000000 // Milliseconds
        // }],
        view: 'month',
        tmpl_path: '/static/bootstrap-calendar/tmpls/',
        tmpl_cache: false,
        // day: '2013-03-12',
        onAfterEventsLoad: function(events) {
            // console.log(events)
            if(!events) {
                return;
            }
            var list = $('#eventlist');
            list.html('');

            $.each(events, function(key, val) {
                if ($.py.append_add_module_link) {
                    $(document.createElement('li'))
                        .html('<a href="' + val.url + '">' + val.title + '</a>')
                        .appendTo(list);
                } else {
                    $(document.createElement('li'))
                        .html('<a href="' + val.url + '">' + val.title + ', <span class="red">zoom: ' + val.zone + '</span></a>')
                        .appendTo(list);
                }

            });
        },
        onAfterViewLoad: function(view) {
            // console.log('onAfterViewLoad called');
            $('.page-header h3').text(this.getTitle());
            $('.btn-group button').removeClass('active');
            $('button[data-calendar-view="' + view + '"]').addClass('active');

            // console.log($('.cal-day-inmonth'));
            if($.py.append_add_module_link) {
                $('.cal-day-inmonth').each(function(){
                    var ymd = $(this).children().attr('data-cal-date').split('-')
                    var add_lecture_url = $.py.add_lecture_url + '?year=' + ymd[0] + '&month=' + ymd[1] + '&day=' + ymd[2];
                    var add_exam_url = $.py.add_exam_url + '?year=' + ymd[0] + '&month=' + ymd[1] + '&day=' + ymd[2];

                    var link1 = $("<div class='tooltip'><a class='pull-left add-module' href='" + add_lecture_url + "'><span class='glyphicon glyphicon-edit'></span><span class='tooltiptext'>Create a lecture</span></div>");

                    var link2 = $("<div class='tooltip'><a class='pull-left add-module' href='" + add_exam_url + "'><span class='glyphicon glyphicon-list-alt'></span></a><span class='tooltiptext'>Create a exam</span></div>");
                    $(this).prepend(link2);
                    $(this).prepend(link1);
                });
            }

            if($.py.user_role && $.py.user_role == 'supervisor') {
                $('#eventlist').parent().hide();
                $("#conflict-wrapper").hide();
                if (view === 'month') {
                    $("#conflict-wrapper").show();
                } else if (view === 'day') {
                    $('#eventlist').parent().show();
                }
            }
        },
        classes: {
            months: {
                general: 'label'
            }
        }
    };

    calendar = $('#calendar').calendar(options);

    $('.btn-group button[data-calendar-nav]').each(function() {
        var $this = $(this);
        $this.click(function() {
            calendar.navigate($this.data('calendar-nav'));
        });
    });

    $('.btn-group button[data-calendar-view]').each(function() {
        var $this = $(this);
        $this.click(function() {
            if($this.data('calendar-view') == 'month') {
                $('#conflict').show();
            }
            calendar.view($this.data('calendar-view'));
        });
    });

    $('#first_day').change(function(){
        var value = $(this).val();
        value = value.length ? parseInt(value) : null;
        calendar.setOptions({first_day: value});
        calendar.view();
    });

    $('#language').change(function(){
        calendar.setLanguage($(this).val());
        calendar.view();
    });

    $('#events-in-modal').change(function(){
        var val = $(this).is(':checked') ? $(this).val() : null;
        calendar.setOptions({modal: val});
    });
    $('#format-12-hours').change(function(){
        var val = $(this).is(':checked') ? true : false;
        calendar.setOptions({format12: val});
        calendar.view();
    });
    $('#show_wbn').change(function(){
        var val = $(this).is(':checked') ? true : false;
        calendar.setOptions({display_week_numbers: val});
        calendar.view();
    });
    $('#show_wb').change(function(){
        var val = $(this).is(':checked') ? true : false;
        calendar.setOptions({weekbox: val});
        calendar.view();
    });
    $('#events-modal .modal-header, #events-modal .modal-footer').click(function(e){
        //e.preventDefault();
        //e.stopPropagation();
    });
}(jQuery));