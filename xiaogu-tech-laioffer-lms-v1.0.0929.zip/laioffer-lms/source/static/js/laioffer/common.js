// _header.html
// update current_group
$('span.change-group').on('click', function(){
    // console.log('clicked');
    var userid = $(this).data('user_id');
    var data = {
        'current_group': $(this).data('group_name'),
    }
    var context = {}
    update_user(userid, 'PATCH', data, context, current_group_updated);
});

function current_group_updated(res, ctx) {
    // console.log(ctx);
    // location.reload();

    var href = $('div.brand a').attr('href');
    window.location.href = href;
}
// update current_group end

$(document).ready(function(){
    hightlightn_sidebar($(location).attr('pathname'));
});

// _teacher_sidebar  and _admin_sidebar
// set desired a link active
function hightlightn_sidebar(url) {
    $('ul#nav-accordion').find('li a').each(function() {
        // console.log($(this).attr('href'));
        if ($(this).attr('href') == url) {
            $(this).addClass('active');
            if ($(this).parents('li.sub-menu')) {
                $(this).parents('li.sub-menu').children(":first").addClass('active');
                $(this).parents('li.sub-menu').find('ul.sub').show();
            }
        }
    });
}

// course views
$('div.course-class-view-tabs a').each(function() {
    if ($(this).attr('href') == $(location).attr('pathname')) {
        $(this).addClass('active');
        var url = $(this).parent().parent().data('highlight_url');
        hightlightn_sidebar(url);
    }
});
