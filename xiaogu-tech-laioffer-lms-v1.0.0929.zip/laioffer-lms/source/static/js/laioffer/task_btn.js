function finish_task() {
    var status = $(this).data('status');
    // console.log(status);
    var taskid = $(this).data('task_id');
    var data = {
        'status': status,
    }
    var context = {
        'cb': $(this),
    }
    update_task(taskid, 'PATCH', data, context, goback_page);
}


function goback_page() {
    var url = $('input.pre_url').val();
    window.location.href = url;
}

function add_button(status, span) {
    var dict = {'Not Scheduled': 'TODO', 'Scheduled': 'DOING'};
    var btn = $('<button type="button" data-task_id="' + $.py.task_id + '" class="btn btn-primary js-task-btn"></button>');
    btn.on('click', finish_task);
    if (status == 'DONE' || status == 'TODO' || status == 'DOING') {
        btn.html('mark task as ' + status);
    } else {
        btn.html(status);
        status = dict[status]
    }
    btn.data('status', status);
    span.after(btn);
}

function show_task_btns() {
    var span = $('#task_status');
    var interview = false;
    if ( !span.length ) {   /* 如果是 interview 页面，提示语变化 */
        span = $('#task_status_interview');
        interview = true;
    }
    if (span.length) {
        span.hide();
        if (span.data('task_status') == 'DONE') {
            if (interview) {
                add_button('Scheduled', span);
                add_button('Not Scheduled', span);
            }else {
                add_button('TODO', span);
                add_button('DOING', span);
            }
        }
        else if (span.data('task_status') == 'TODO') {
            if (interview) {
                add_button('Scheduled', span);
                add_button('DONE', span);
            }else {
                add_button('DOING', span);
                add_button('DONE', span);
            }
        }
        else if (span.data('task_status') == 'DOING') {
            if (interview) {
                add_button('Not Scheduled', span);
                add_button('DONE', span);
            }else {
                add_button('TODO', span);
                add_button('DONE', span);
            }
        }
        else {
            console.log('unknown status!');
        }
    }
}

$(document).ready(function() {
    show_task_btns();
});
