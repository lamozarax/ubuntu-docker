function assigneeChanged() {
    // console.log(this.value);
    var taskid = $(this).parent().data('task_id');

    if (taskid == '') {

        var ttype = $(this).parent().data('task_type');
        var data = {
            'assignee': $(this).val(),
            'assignor': $.py.assignor_id,
            'ttype': ttype,
        }
        if (ttype) {
            var target_id = $(this).parent().data('target_id')
            data[ttype] = target_id;
        }
        // console.log(data);
        var context = {
            'td_status': $(this).parent().parent().prev(),
        }
        create_task(data, context, update_status);
    } else {
        var data = {
            'assignee': this.value,
        }
        var context = {}
        update_task(taskid, 'PATCH', data, context);
    }
}

function bulkupdate() {
    $('input.cb').each(function() {
        var assignee = $('#bulk_update').parent().find('select').val();
        if ($(this).is(':checked')) {
            // console.log('task_type: ' + $(this).data('task_type') + ', target_id: ' + $(this).data('task_id') + ', assignee: ' + assignee);
            var taskid = $(this).data('task_id');
            if (taskid == '') {
                // create
                var ttype = $('#bulk_update').data('ttype');
                var data = {
                    'assignee': assignee,
                    'assignor': $.py.assignor_id,
                    'ttype': ttype,
                }
                if (ttype) {
                    var target_id = $(this).data('target_id')
                    data[ttype] = target_id;
                }
                // console.log(data);
                var context = {
                    'td_status': $(this).parent().parent().prev().prev(),
                    'cb': $(this),
                    'assignee': assignee,
                }
                create_task(data, context, update_assignee);
            }
            else {
                // update
                var data = {
                    'assignee': assignee,
                }
                var context = {
                    'cb': $(this),
                    'assignee': assignee,
                }
                update_task(taskid, 'PATCH', data, context, update_assignee);
            }
        }
    });
}

function update_assignee(res, ctx) {
    // console.log(ctx);
    ctx.cb.prop('checked', false);
    ctx.cb.parent().parent().parent().find('select').val(ctx.assignee);
    $('#checkall').prop('checked', false);

    if (ctx.td_status) {
        update_status(res, ctx);
    }
}

function update_status(res, ctx) {
    var span = ctx.td_status.find('span');
    span.removeClass('label-default');
    span.addClass('label-warning');
    span.html(res['status']);
}

function appendTaskSelect(target) {
    var current_val = target.data('assignee_info');
    var div = $('#taskselect').clone();
    var sel = div.find('select');
    sel.val(current_val);
    sel.on('change', assigneeChanged);
    target.append(sel);
}

$(document).ready(function() {
    // $("#taskselect").hide();
    $('#bulk_update').on('click', bulkupdate);

    $(".assignee-select").each(function() {
        appendTaskSelect($(this));
    });

    $('#checkall').change(function() {
        var checked = this.checked;
        $('input.cb').each(function() {
            $(this).prop('checked', checked);
        });
    });
});
