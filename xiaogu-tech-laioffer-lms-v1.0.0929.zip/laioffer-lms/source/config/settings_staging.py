"""
Django settings for LMS project.
"""

from .settings_base import *
import os


# SECURITY WARNING: don't run with debug turned on in production!
DEBUG = False

ALLOWED_HOSTS = ['*']
# ALLOWED_HOSTS = ['127.0.0.1', 'SITENAME']

MEDIA_ROOT = '/sites/SITENAME/'
MEDIA_URL = 'http://SITENAME/'

TIME_ZONE = 'US/Pacific'

# Database
# https://docs.djangoproject.com/en/1.11/ref/settings/#databases

DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.postgresql_psycopg2',
        'HOST': os.environ.get('LMS_DB_HOST'),
        'PORT': os.environ.get('LMS_DB_PORT'),
        'NAME': os.environ.get('LMS_DB_NAME'),
        'USER': os.environ.get('LMS_DB_USER'),
        'PASSWORD': os.environ.get('LMS_DB_PWD'),
    }
}

