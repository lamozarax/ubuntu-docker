from django import forms
from markdownx.fields import MarkdownxFormField

from user.contants import GROUP_ASSISTANT
from user.models import User


class MarkdownxTestForm(forms.Form):
    myfield = MarkdownxFormField()


class SelectAssigneeForm(forms.Form):

    assign_to = forms.ModelChoiceField(queryset=None, label='')

    def __init__(self, *args, **kwargs):
        super(SelectAssigneeForm, self).__init__(*args, **kwargs)
        self.fields['assign_to'].queryset = User.objects.filter(
            groups__name=GROUP_ASSISTANT)
        self.fields['assign_to'].widget.attrs.update({
            'class': 'input-sm form-control w-sm inline v-middle',
        })
