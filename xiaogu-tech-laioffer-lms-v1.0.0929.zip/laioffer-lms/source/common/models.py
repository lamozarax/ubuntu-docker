from django.db import models
from django.conf import settings

from markdownx.models import MarkdownxField


class TimeStampedModel(models.Model):
    """
    An abstract base class model that provides self-
    updating ``created`` and ``modified`` fields.
    """
    created = models.DateTimeField(auto_now_add=True)
    modified = models.DateTimeField(auto_now=True)

    class Meta():
        abstract = True


class MyModel(models.Model):
    myfield = MarkdownxField()
    if settings.DEBUG:
        myfile = models.FileField(upload_to='static/uploads/%Y/%m/%d/')
    else:
        myfile = models.FileField(
            upload_to='../collected_static/uploads/%Y/%m/%d/')
