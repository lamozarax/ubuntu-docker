# permission related
class PERMS(object):

    IS_SUPERVISOR = 'user.is_supervisor'
    IS_TEACHER = 'user.is_teacher'
    IS_STUDENT = 'user.is_student'
    IS_ASSISTANT = 'user.is_assistant'
