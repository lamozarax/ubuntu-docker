from rest_framework import serializers

from .models import InlineComment, Answer


class InlineCommentSerializer(serializers.ModelSerializer):

    # commenter = serializers.StringRelatedField()
    # answer = serializers.PrimaryKeyRelatedField(read_only=True)
    # answer = serializers.IntegerField(read_only=True, source='answer.id')
    commenter_name = serializers.SerializerMethodField()

    def get_commenter_name(self, inline_comment):
        return inline_comment.commenter.username

    class Meta:
        model = InlineComment
        fields = ('id', 'linenum', 'content',
                  'is_amendment', 'commenter',
                  'answer', 'commenter_name', 'modified')


class AnswerSerializer(serializers.ModelSerializer):

    class Meta:
        model = Answer
        fields = '__all__'
