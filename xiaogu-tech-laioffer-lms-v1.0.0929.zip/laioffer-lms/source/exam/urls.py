from django.conf.urls import url, include
from rest_framework.routers import DefaultRouter

from . import views
from . import apis

router = DefaultRouter()
router.register(r'comments', apis.InlineCommentViewSet)
router.register(r'answers', apis.AnswerViewSet)


urlpatterns = [
    url(
        regex=r'^api/',
        view=include(router.urls),
    ),
    url(
        regex=r"^api2/answer/(?P<answer_id>\d+)/comments/",
        view=apis.InlineCommentListByAnswer.as_view(),
        name='get_comments_by_answer'
    ),
    url(
        regex=r"^api2/(?P<exam_id>\d+)/student/(?P<student_id>\d+)/comments/",
        view=apis.InlineCommentListByExam.as_view(),
        name='get_comments_by_exam'
    ),
    url(
        regex=r"^(?P<exam_id>\d+)/summary/$",
        view=views.ExamSummaryView.as_view(),
        name='summary'
    ),
    url(
        regex=r"^(?P<exam_id>\d+)/student/$",
        view=views.ExamStudentView.as_view(),
        name='student'
    ),
    url(
        regex=r"^score/paper/(?P<exam_paper_id>\d+)/$",
        view=views.ExamScoreView.as_view(),
        name='score'
    ),
    url(
        regex=r"^update/answer/",
        view=apis.UpdateAnswerApi.as_view(),
        name='update_answer'
    ),
    url(
        regex=r"^course/(?P<pk>\d+)/$",
        view=views.ExamClassView.as_view(),
        name='class_view'
    ),

]
