from django.contrib import admin

from .models import Answer, Exam, Problem


class ProblemInline(admin.StackedInline):
    model = Problem


@admin.register(Exam)
class ExamAdmin(admin.ModelAdmin):
    list_display = ['title']
    inlines = [ProblemInline]


admin.site.register(Answer)
