from django import forms
from django.utils.translation import ugettext_lazy as _

from .models import ResumeComment, Resume


class ResumeCommentForm(forms.ModelForm):

    class Meta:
        model = ResumeComment
        fields = ['text']
        labels = {
            'text': _('comment here'),
        }


class ResumeTeacherCommentForm(forms.ModelForm):

    class Meta:
        model = ResumeComment
        fields = ['text', 'attachment']
        labels = {
            'text': _('comment here'),
        }


class ResumeCreateForm(forms.ModelForm):

    class Meta:
        model = Resume
        fields = ['desc', 'file']
